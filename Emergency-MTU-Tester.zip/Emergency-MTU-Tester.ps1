# ===============================================================
# Emergency MTU Tester & Temporary MTU Setter (v1.0.0)
# ! This tool is intended ONLY for emergency / abnormal network cases.
# ! No files are created. No persistent configuration except MTU.
# This file is auto-generated. Do not edit manually.
# ===============================================================

# --- Universal exit function ---
function Stop-And-Wait([string]$Message) {
    Write-Host ""
    Write-Host $Message
    Write-Host "Press ENTER to exit..."
    [void][System.Console]::ReadLine()
    exit
}

# --- Self-elevate to Admin if needed (PS5 + PS7 safe) ---
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

Write-Host ""
Write-Host "Emergency MTU Tester starting..." -ForegroundColor Cyan

# --- Detect active IPv4 adapter ---
$adapter = (Get-NetIPInterface |
    Where-Object { $_.AddressFamily -eq "IPv4" -and $_.ConnectionState -eq "Connected" } |
    Select-Object -First 1).InterfaceAlias

if (-not $adapter) {
    Stop-And-Wait "No active IPv4 adapter found. Cannot test MTU."
}

Write-Host "Testing MTU for adapter: $adapter"
Write-Host ""

# --- MTU test function ---
function Test-MTU {
    param([int]$size)

    $result = ping 1.1.1.1 -f -l $size -n 1

    if ($result -match "Packet needs to be fragmented" -or
        $result -match "fragmentation needed" -or
        $result -match "DF set") {
        return $false
    }

    return $true
}

# --- MTU brute-force search ---
$maxPayload = 1500 - 28
$optimal = 0

Write-Host "Searching for optimal MTU..."
for ($i = $maxPayload; $i -ge 1200; $i--) {
    if (Test-MTU -size $i) {
        $optimal = $i + 28
        break
    }
}

# --- Apply MTU ---
if ($optimal -gt 0) {
    Write-Host ""
    Write-Host "Optimal MTU found: $optimal" -ForegroundColor Green

    Write-Host "Applying MTU $optimal..."
    netsh interface ipv4 set subinterface "$adapter" mtu=$optimal store=persistent | Out-Null
    netsh interface ipv6 set subinterface "$adapter" mtu=$optimal store=persistent | Out-Null

    Write-Host "MTU applied persistently."
    Stop-And-Wait "Emergency MTU test completed successfully."
}
else {
    Stop-And-Wait "Could not determine MTU. No changes applied."
}
